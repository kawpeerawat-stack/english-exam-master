// app/lib/cloud.ts
// ─────────────────────────────────────────────────────────────
// อ่านข้อมูลนักเรียนจาก Firestore โปรเจกต์เดิม (smart-vocab-master)
//   - ใช้ collection "students" ร่วมกับแอป vocab → ล็อกอิน/แต้ม/streak เป็นระบบเดียวกัน
//   - แอปนี้ (สอบจำลอง) จะ "เพิ่ม" ผลสอบลง collection ใหม่ภายหลัง (Phase 5) ไม่ทับข้อมูลเดิม
// document id = อีเมล (พิมพ์เล็ก)
// ─────────────────────────────────────────────────────────────

import { db } from "./firebase";
import { doc, getDoc, collection, getDocs } from "firebase/firestore";

const COLLECTION = "students";

export function emailToId(email: string): string {
  return email.trim().toLowerCase().replace(/\//g, "_");
}

// รหัสสัปดาห์ = วันที่ของ "วันจันทร์" ของสัปดาห์นั้น → อันดับรีเซ็ตทุกวันจันทร์ (ตรงกับแอป vocab)
export function currentWeekId(d: Date = new Date()): string {
  const x = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  const day = (x.getDay() + 6) % 7; // จันทร์=0 ... อาทิตย์=6
  x.setDate(x.getDate() - day);
  return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, "0")}-${String(x.getDate()).padStart(2, "0")}`;
}

export interface StudentProfile {
  name: string;
  email: string;
  weeklyXp: number;   // แต้มสัปดาห์นี้ (0 ถ้าเป็นของสัปดาห์ก่อน)
  streak: number;
  bestStreak: number;
}

// โหลดโปรไฟล์นักเรียน (คืน null ถ้ายังไม่เคยมีในระบบ)
export async function loadStudent(email: string): Promise<StudentProfile | null> {
  if (!email || !db) return null;
  try {
    const ref = doc(db, COLLECTION, emailToId(email));
    const snap = await getDoc(ref);
    if (!snap.exists()) return null;
    const d = snap.data() as {
      name?: string; email?: string;
      weeklyXp?: number; weekId?: string;
      streak?: number; bestStreak?: number;
    };
    const thisWeek = currentWeekId();
    return {
      name: d.name || "",
      email: (d.email || email).toLowerCase(),
      weeklyXp: d.weekId === thisWeek ? (d.weeklyXp ?? 0) : 0,
      streak: d.streak ?? 0,
      bestStreak: d.bestStreak ?? 0,
    };
  } catch (e) {
    console.error("loadStudent error:", e);
    return null;
  }
}

export interface WeeklyRankEntry {
  email: string;
  name: string;
  weeklyXp: number;
}

// อันดับ "คนขยันสัปดาห์นี้" — จัดอันดับจาก weeklyXp (รวมทุกกิจกรรม รีเซ็ตทุกจันทร์)
// ภายหลัง (Phase 5) คะแนนสอบจำลองจะบวกเข้า weeklyXp ด้วย → อันดับนับรวมการสอบจำลอง
export async function loadWeeklyLeaderboard(): Promise<WeeklyRankEntry[]> {
  if (!db) return [];
  try {
    const thisWeek = currentWeekId();
    const snap = await getDocs(collection(db, COLLECTION));
    const entries: WeeklyRankEntry[] = [];
    snap.forEach((s) => {
      const d = s.data() as { email?: string; name?: string; weeklyXp?: number; weekId?: string };
      const weeklyXp = d.weekId === thisWeek ? (d.weeklyXp ?? 0) : 0;
      if (weeklyXp > 0) {
        entries.push({
          email: (d.email || s.id).toLowerCase(),
          name: d.name || "(ไม่มีชื่อ)",
          weeklyXp,
        });
      }
    });
    entries.sort((a, b) => b.weeklyXp - a.weeklyXp);
    return entries;
  } catch (e) {
    console.error("loadWeeklyLeaderboard error:", e);
    return [];
  }
}
